# 来源、证据类型与维护

表现层扩展的一手链接就近保留在 [中国空间/书画](styles/chinese.md)、[古典装饰](styles/classical-ornament.md)、[现代实验](styles/modern-experimental.md)、[作者与品牌](brand-identity.md)、[产品](product-patterns.md)、[企业系统](enterprise-expression.md)。这些模块区分历史背景、作者说明、本 skill 的转译与待实测内容；不要求为了一个任务读完全部来源。

基础资料核对：2026-10-03；扩展资料核对：2026-10-04。链接用于在相关任务中定向查阅，不要求每次读取全部文献。动态平台页面使用前复核；原始实验支持其研究条件下的结论，不自动支持本文所有 UI 应用。工作流、应用表和例子是综合判断，不应把其中每个建议都冒称原作者结论。

## 标准与实现资料

| 来源 | 类型 / 用途 |
|---|---|
| [WCAG 2.2](https://www.w3.org/TR/WCAG22/) | W3C Recommendation；正式合规以标准条款、级别和范围为准 |
| [文字对比](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html) | 官方解释；普通与大号文字阈值及例外 |
| [非文本对比](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html) | 官方解释；必要控件/图形信息及例外 |
| [目标尺寸](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum) | 官方解释；24 CSS px 条款、间距与其他例外 |
| [重排](https://www.w3.org/WAI/WCAG22/Understanding/reflow.html) | 官方解释；320 CSS px 相应情形与二维内容例外 |
| [文字间距](https://www.w3.org/WAI/WCAG22/Understanding/text-spacing.html) | 官方解释；用户改变间距时保持内容与功能 |
| [焦点不被遮挡](https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum) | 官方解释；AA 最低要求与更高目标的区别 |
| [WAI-ARIA APG](https://www.w3.org/WAI/ARIA/apg/patterns/) | 官方实践指导；控件模式、语义与键盘行为；不是整体合规证明 |
| [Design Tokens Format 2025.10](https://www.designtokens.org/tr/2025.10/format/) | DTCG 社区组规格；类型、分组、别名、复合值；非 W3C Recommendation |
| [MDN line-height](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/line-height) | 浏览器开发参考；行框、继承与无单位行高 |
| [MDN flex](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/flex) | 浏览器开发参考；增长/收缩及最小尺寸 |

Understanding 文档属于解释性材料，不取代 WCAG 规范性正文。项目另有目标标准时重新确定适用性。

## 用户研究与经验模型

| 来源 | 可以支持什么 / 边界 |
|---|---|
| [Nielsen：10 项可用性启发式](https://www.nngroup.com/articles/ten-usability-heuristics/) | 作者的经验原则；不是硬性尺寸规范 |
| [GOV.UK：理解用户需求](https://www.gov.uk/service-manual/user-research/start-by-learning-user-needs) | 用户研究实践；对人、任务、现状与障碍持续研究 |
| [Design Council：双钻](https://www.designcouncil.org.uk/resources/framework-for-innovation/) | 探索/聚焦的问题与方案过程；不要求机械线性阶段 |
| [Google：HEART 原论文](https://research.google/pubs/measuring-the-user-experience-on-a-large-scale-user-centered-metrics-for-web-applications/) | 体验目标与指标；按任务选择，而非最大化所有指标 |
| [Fitts 1954 原论文记录](https://doi.org/10.1037/h0055392) | 运动幅度与目标容差相关实验；不可无限外推 |
| [Hick 1952 原论文](https://journals.sagepub.com/doi/10.1080/17470215208416600) | 选择反应实验；并非任何网页菜单的直接预测公式 |
| [Miller 1956 原文重印](https://psychclassics.yorku.ca/Miller/) | 信息处理、判断和记忆相关讨论；不规定导航数量 |
| [Tractinsky 等，2000](https://academic.oup.com/iwc/article-abstract/13/2/127/898608) | 外观与感知易用性研究；不能等同于实际任务成功 |

原论文受限访问时，仅对可见摘要与可核实内容作判断，不能假装阅读全文。原则库中关于常见效应的应用边界是谨慎的实践提醒；若要据此作具体因果预测，需进一步查阅原始研究与相关人群研究。

## 平台设计

| 来源 | 范围与注意事项 |
|---|---|
| [Apple HIG Materials](https://developer.apple.com/design/human-interface-guidelines/materials) | Liquid Glass 与标准材质的角色，不是全界面玻璃处方 |
| [Apple HIG Accessibility](https://developer.apple.com/design/human-interface-guidelines/accessibility) | 平台与能力适配；不同设备建议不同 |
| [Apple HIG Buttons](https://developer.apple.com/design/human-interface-guidelines/buttons) | 系统按钮、命中区与状态 |
| [Material 3](https://m3.material.io/) | Google 设计系统；版本与组件需在实施时确认 |
| [Material 3 Expressive 研究](https://design.google/library/expressive-material-design-google-research) | 团队原始研究说明；官方也提醒有人偏好平静表达，不能直接推广所有人群 |
| [Android 可访问性设计](https://developer.android.com/design/ui/mobile/guides/foundations/accessibility) | Android 移动设计建议，包括 48 dp 目标 |
| [Fluent 设计原则](https://fluent2.microsoft.design/design-principles) | 平台适应、专注、包容与品牌联系 |
| [Fluent 材质](https://fluent2.microsoft.design/material) | Solid、Mica、Acrylic、Smoke 的角色 |
| [Windows 材质](https://learn.microsoft.com/en-us/windows/apps/design/signature-experiences/materials) | Windows 实现环境；与 Web 不直接等价 |
| [HyperOS 官网](https://hyperos.mi.com/) | 当前品牌/产品介绍，非全面第三方实现规范；不采信宣传性能为实测结果 |
| [HarmonyOS 当前设计入口](https://developer.huawei.com/consumer/cn/design/) | 当前设计语言、组件与多端方向；版本需确认 |
| [HarmonyOS 设计概念](https://developer.huawei.com/consumer/cn/design/concept/) | 概念性资料；不能自动当作全部当前规范 |
| [HarmonyOS 折叠屏原则](https://developer.huawei.com/consumer/cn/doc/doccenter-ux-design/design-principles-0000001957023989) | 形态变化、布局兼容与任务连续 |
| [OriginOS 中文官网](https://www.vivo.com.cn/originos) | 当前产品表达与功能介绍；不等于所有地区/机型状态 |

## 历史与文化

| 来源 | 用途 |
|---|---|
| [Windows Phone Metro 指南公告，2010](https://blogs.windows.com/windowsdeveloper/2010/03/18/windows-phone-7-series-ui-design-interaction-guide/) | 历史时间线，不能当作当前 Windows 规范 |
| [iOS 7 公告，2013](https://www.apple.com/newsroom/2013/06/10Apple-Unveils-iOS-7/) | Apple 当时的产品发布事实，不把宣传形容词作审美结论 |
| [Vista Aero Glass 技术文献，2007](https://learn.microsoft.com/en-us/archive/msdn-magazine/2007/april/aero-glass-create-special-effects-with-the-desktop-window-manager) | 玻璃视觉与合成技术并非最新才出现 |
| [Dieter Rams 十原则](https://www.vitsoe.com/us/about/good-design) | 设计师的价值立场，不是所有产品的经验定律 |
| [原研哉谈 MUJI](https://www.muji.com/my/flagship/huaihai755/archive/hara.html) | “空”与使用者赋义，不能代表全部日本文化 |
| [大都会博物馆：中国山水画](https://www.metmuseum.org/es/essays/landscape-painting-in-chinese-art) | 具体传统的文化与表达语境，不据此预测当代个体偏好 |
| [MoMA：极简主义材料](https://www.moma.org/collection/terms/minimalism/the-materials-of-minimalism) | 艺术史 Minimalism 与一般 UI 简约的区别 |
| [V&A：后现代主义](https://www.vam.ac.uk/articles/what-is-postmodernism) | 历史语境；转译到交互仍需独立判断 |

## 维护规则

需要具体平台实施时重新验证相关页面与版本，不每次全量查证。新增主张应有对应来源或标作设计判断；弃用、冲突和无法确认的信息显式记录。不把规范、厂商宣传、研究证据与个人审美混成一种权威。

## 本次扩展：模型、心理学与行为

| 一手来源或原文重印 | 本次用途与证据边界 |
|---|---|
| [Garrett《The Elements of User Experience》原书，院校资料库副本](https://paul.zhdk.ch/pluginfile.php/109031/mod_folder/content/0/UI%20Design%20Literature/Jesse%20James%20Garrett-The_Elements_of_User_Experience.pdf) | 核对五层及功能/内容区别；作者原网站本次抓取失败，未声称完整读过全书。跨平面与演示的转译是本 skill 综合 |
| [Don Norman：修订版《The Design of Everyday Things》](https://jnd.org/books/the-design-of-everyday-things-revised-and-expanded-edition/) | 作者书籍说明与目录，核对心智模型、映射、意符、反馈、执行/评价及错误等关注点；不是本轮整本书研究 |
| [Gestalt 百年回顾，2012，原作者论文](https://pmc.ncbi.nlm.nih.gov/articles/PMC3728284/) | 知觉组织与理论边界；不能由知觉分组推出任何界面自动易用 |
| [SDT 理论说明](https://selfdeterminationtheory.org/the-theory/) | 自主、胜任、联结及动机框架；不证明游戏积分一定提高动机 |
| [Fogg Behavior Model](https://www.behaviormodel.org/) | 作者的动机、能力、提示框架；以诊断启发使用，不照搬其普适性主张为已证定律 |
| [Michie 等，COM-B / Behaviour Change Wheel，2011](https://pmc.ncbi.nlm.nih.gov/articles/PMC3096582/) | 原始论文；能力、机会、动机与行为框架，产品设计迁移需验证 |
| [Kahneman、Tversky，Prospect Theory，1979 原文副本](https://ethz.ch/content/dam/ethz/special-interest/mtec/necom-dam/documents/ANS-2018/papers/3_Kahneman_Tversky_Prospect_Theory.pdf) | 风险选择与参考点框架；不等于“所有营销中损失影响固定两倍” |
| [Scheibehenne 等，选择过载元分析，2010](https://doi.org/10.1086/651235) | 可见摘要指出跨研究平均效应与差异；支持避免“选项越少越好”的简单断言，不能宣布任何具体产品都无选择过载 |
| [Intercom：RICE](https://www.intercom.com/blog/rice-simple-prioritization-for-product-managers/) | 团队原始实践框架；覆盖、影响、信心与投入辅助排序，不应伪造分值 |
| [WCAG：交互触发动画](https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html) | 2.3.3 为 AAA，区别自动运动等条款；减少动态方案仍应保留功能 |

5W2H、MoSCoW、JTBD、Kano、旅程、服务蓝图、构思方法及 GOMS/KLM 在本库仅提供简短的工作选择入口，没有宣称本轮完成各体系的全量文献验证。若项目需要正式评分、量表、精确预测或归属历史，应定向查阅原始方法与版本后使用，不能凭这个缩写索引编造“科学分数”。社会证明、锚定等条目同样不包含可直接套用的效应量。

## 本次扩展：产品、出版与公开技能

| 来源 | 读取范围 |
|---|---|
| [Linear 重构过程](https://linear.app/now/how-we-redesigned-the-linear-ui) | 团队案例说明，层级、密度、变量及实施；没有实测其所有客户端 |
| [Procreate iPadOS 26 适配说明](https://procreate.com/insight/2025/iPadOS-26) | 官方更新说明；不是最新全部功能清单 |
| [2026 Apple Design Awards](https://developer.apple.com/design/awards/) | 官方获奖/入围资料；奖项标准与目标人群有所选择，不是通用效果认证 |
| [Pentagram 出版设计](https://www.pentagram.com/editorial-design) | 官方案例索引与方法说明；未逐个项目做视觉评审 |
| [Anthropic frontend-design](https://github.com/anthropics/skills/blob/main/skills/frontend-design/SKILL.md) | 2026-10-04 读取的公开入口；动态 main 分支可能变化，未做产物能力排名 |
| [UI UX Pro Max](https://github.com/nextlevelbuilder/ui-ux-pro-max-skill) | 同日公开说明；功能声明与实际效果不同，未运行其工具或做比较实验 |

引用内容以简短概括与链接为主，不复制第三方手册、skill 全文、字体、模板或受限制资产。本库不通过上述链接授权执行远端脚本。
