# 平台语言、历史与品牌权威

资料核对日期：2026-10-03。以下是当日可访问官方资料的摘要与设计判断，不能代替目标设备、地区和版本的实测。动态官网可能变化；实施时复核最新适用文档。官方宣传支持“品牌这样描述自己”，不直接证明“用户更满意”或“性能更好”。

## 比较口径

- Apple 是多平台 HIG 与原生框架的体系，不能用一张 iPhone 页面概括全部设备。
- Android 是平台生态，Material 是 Google 的设计系统；Android 应用与厂商系统并不全部采用相同 Material 表现。
- Windows 是系统，Fluent 覆盖更广泛的 Microsoft 产品；Windows 原生材质与 Fluent Web 实现存在环境差异。
- MIUI 是小米的历史系统系列，讨论当代小米需纳入 HyperOS。当前查阅官网显示 HyperOS 4；具体机型适用性以实际版本为准。
- 本文将“vivoOS”按 vivo 手机系统 OriginOS 理解；当前中文官网显示 OriginOS 7。不能把它与 vivo BlueOS 或所有地区的历史 Funtouch OS 混为一体。
- HarmonyOS 的设计文档、系统版本、设备形态及开发栈需要单独确认，不能把它简单视为另一套 Android 皮肤。

## 不只比较表面材质

| 体系 | 官方资料可确认的侧重点 | 对 UI 的实际含义（综合判断） | 不能简单外推 |
|---|---|---|---|
| Apple HIG | 内容与控制分层；原生组件；跨设备的一致与适应；Liquid Glass 有明确角色 | 原生系统控件优先承担系统行为，品牌表达与内容层保持联系，适配辅助功能 | 不能把任何半透明卡片称为 Apple 规范，也不能所有背景都玻璃化 |
| Material 3 / Expressive | 系统化组件、主题、形状、色彩、排版与动效；表达性与功能并重 | 明确角色 token，按用户任务选择表达强度；适配 Android 导航与设备 | 不代表所有 Android 系统的唯一长相；更鲜艳不保证更受欢迎 |
| Fluent / Windows | 平台自然性、专注、包容、品牌联系；材料按用途分配 | 桌面工作中的窗口、焦点、键盘、多任务和密度需一起设计 | Mica 并非实时透明玻璃；Web 模糊不等价于原生材质 |
| MIUI → HyperOS | 后续体系强调生命感、材质/光影/空间、个性表达及设备协同 | 借鉴需看系统操作和品牌一致性，而不只复制控制中心 | 当前营销页面不构成完整第三方开发规范；不能反推早期 MIUI 所有版本 |
| HarmonyOS | 当前设计入口强调空间、材质、响应、多设备连续性；其他指南涉及卡片、字体与折叠形态 | 设计对象包括多端流转与形态变化，界面结构和状态应延续 | 某年代的设计概念页不一定覆盖当前所有组件 |
| OriginOS | 当前官网强调光影、连续动效、个性化、图标及场景反馈 | 检查快速中断、长时间使用与各状态协调，不只看宣传动图 | 中文官网表达不等于所有市场机型已采用，宣传性能不作实测结论 |

出处：[Apple 材质](https://developer.apple.com/design/human-interface-guidelines/materials)、[Material 3](https://m3.material.io/)、[Google Expressive 研究](https://design.google/library/expressive-material-design-google-research)、[Fluent 原则](https://fluent2.microsoft.design/design-principles)、[HyperOS](https://hyperos.mi.com/)、[HarmonyOS 设计](https://developer.huawei.com/consumer/cn/design/)、[OriginOS](https://www.vivo.com.cn/originos)。

## 趋同与差异

从这些资料可观察到的共同方向包括内容层级、柔和形状、材质与光影、连续反馈、可配置表达和跨设备适应。不能只凭同时采用某效果，断言发生了具体抄袭；需要时间线、结构对应和来源证据。

相似性的可能解释包括：相近的触屏与显示条件、成熟组件惯例、共同用户需求、图形能力提升以及市场竞争。各因素的贡献需要独立研究，不能由官网推断比例。

更有用的比较维度：

1. 返回、关闭、系统手势与导航模型。
2. 文字角色、密度、触达与多任务。
3. 内容、控件、浮层的空间关系。
4. 状态变化是否跟手、可中断、可恢复。
5. 主题、大字、减少动态与其他访问需求。
6. 设计资源到原生/跨端代码的完整程度。
7. 设备与应用切换时任务是否连续。

品牌一致性通常体现在同一语义与气质；平台适配可以采用不同的组件尺寸、导航和键盘行为。不建议把某平台外观与另一平台的交互习惯随意拼接。

## 玻璃是一个有边界的例子

Apple 将 Liquid Glass 主要用于控制和导航层，并提醒克制使用，内容层有其他材料。这个官方意图并不能自动保证每个实际界面在所有背景下都清楚。[Apple 材质](https://developer.apple.com/design/human-interface-guidelines/materials)

Microsoft 区分实体、Mica、Acrylic 和 Smoke：Mica 是受桌面背景色影响的不透明材料；Acrylic 对应短暂出现、易关闭的表面；Smoke 用于弱化模态下面的区域。[Fluent 材质](https://fluent2.microsoft.design/material)

因此在实施时要定义：材料承担哪种语义、对比如何保持、背景怎样变化、低性能和减少透明度设置下如何处理。一个 CSS backdrop-filter 值不能复现完整平台行为。

## 为什么 Apple 被认为有“定义权”

先区分三种权威：

- **生态规范权**：平台能为自己的开发环境提供组件、默认行为和规范。
- **市场解释力**：某品牌的命名和发布可能被开发者、媒体、用户广泛传播。
- **普遍设计正确性**：需要对应任务与用户的证据，不能由前两者自动推出。

Apple 对设计话语的影响可从系统执行、跨产品联系、开发者资源、传播方式和长期品牌认知等机制理解。这是一组解释框架，不是已经测量出各因素权重的因果结论。

可把机制理解为：稳定的表达进入产品 → 默认组件降低采用成本 → 用户接触形成熟悉度 → 开发者适配与传播提高可见度 → 熟悉度反过来降低选择风险。这个循环可能产生影响力，也可能使历史优势持续；它不是美感证明。

其他品牌同样拥有设计语言：Material、Fluent、HarmonyOS、OriginOS、HyperOS 已经提供反例。是否形成广泛影响还与生态规模、传播、投入持续性、开发资源和执行一致性有关。

## 历史需要分清首创、系统化、普及与命名

这些是不同贡献，不应全部授予同一个品牌。

- 2010 年 Microsoft 已公开 Windows Phone 的 Metro 设计指南，强调排版和标识系统的视觉语言。[2010 年原文](https://blogs.windows.com/windowsdeveloper/2010/03/18/windows-phone-7-series-ui-design-interaction-guide/)
- Apple 在 2013 年发布重新设计的 iOS 7。[Apple 当年公告](https://www.apple.com/newsroom/2013/06/10Apple-Unveils-iOS-7/)
- Microsoft 对 Vista Aero Glass 的技术文献至少在 2007 年已详细描述桌面合成与玻璃效果。[2007 年原文](https://learn.microsoft.com/en-us/archive/msdn-magazine/2007/april/aero-glass-create-special-effects-with-the-desktop-window-manager)

这足以否定“扁平与玻璃都只能由 Apple 发明或定义”的绝对说法，但不证明所有视觉方向有单一可确定的发明者。现实对象隐喻与丰富材质也应分别研究，不把“拟物”简单等同于有阴影。

## 关于“落后却仍受欢迎”

整体落后需要先确定产品、时间、地区、维度和用户权重。某项硬件、功能或定制能力落后，不能自动推出总体验更差；销量或忠诚也不能反证每项设计都更好。

可检验的解释包括：完整任务链、已有设备与内容、迁移/学习成本、可靠性预期、服务、品牌认同和社会意义。不同人权重不同。它们可能包含真实价值，也可能包含偏好或路径依赖；不能把所有选择归因于盲从，也不能把所有选择美化成理性最优。

对设计实践最有用的启发：形成清楚且持续的产品承诺，把表达、行为、组件和实现连接起来，建立自己的判断标准。品牌声望不能替代对比、访问需求与任务失败的具体检查。
