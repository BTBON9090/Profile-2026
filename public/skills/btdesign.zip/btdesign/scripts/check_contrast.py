#!/usr/bin/env python3
"""Opaque sRGB pair contrast; threshold calculation, not a conformance audit."""
import argparse
import json
import re


def rgb(value):
    if not isinstance(value, str) or not re.fullmatch(r"#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?", value):
        raise ValueError("Use opaque sRGB #RGB or #RRGGBB; alpha and other color spaces are unsupported.")
    raw = value[1:]
    if len(raw) == 3:
        raw = "".join(c * 2 for c in raw)
    return [int(raw[i:i + 2], 16) / 255 for i in (0, 2, 4)]


def luminance(value):
    channels = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in rgb(value)]
    return sum(c * weight for c, weight in zip(channels, (0.2126, 0.7152, 0.0722)))


def contrast(foreground, background):
    a, b = sorted((luminance(foreground), luminance(background)))
    return (b + 0.05) / (a + 0.05)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--foreground", required=True)
    parser.add_argument("--background", required=True)
    args = parser.parse_args()
    try:
        ratio = contrast(args.foreground, args.background)
    except ValueError as error:
        parser.error(str(error))
    print(json.dumps({
        "foreground": args.foreground, "background": args.background,
        "ratio": round(ratio, 6),
        "meets_4_5_threshold": ratio >= 4.5,
        "meets_3_threshold": ratio >= 3,
        "meets_7_threshold": ratio >= 7,
        "scope": "opaque sRGB only; thresholds use the unrounded ratio; applicability and exceptions require review"
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
