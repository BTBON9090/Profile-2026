---
name: btdesign
description: "Design, explore, implement, or critique UI/UX, interaction, motion, art direction, brand identity, editorial layouts, presentations, posters, and print graphics. Use for ambiguous briefs, visual style, composition, hierarchy, density, enterprise UI identity, fidelity, or design review. 用于界面、交互、视觉风格、品牌 VI、版式、PPT/Keynote、杂志、海报与易拉宝设计。Exclude backend-only work, plain copy editing, standalone fine art, and history-only discussion unless explicitly invoked."
---

# btdesign

Turn intent and content into clear, distinctive, usable design across media. Preserve the user's scope, brand, stack, assets, and delivery format. Use theories to make decisions, not to decorate explanations. No fixed house style, universal font, color ban, density preset, or mandatory model parade.

## Route by the actual job

Read only relevant modules and sections. Start with this entry and the row that resolves the current decision; follow deeper links only when needed. Do not concatenate the reference library. Reuse material already read in the task. This is an instruction-based loading protocol, not an automatic retrieval engine or a fixed token guarantee.

| Job | Read |
|---|---|
| New design, redesign, unclear brief | [workflow](references/workflow.md), [planning models](references/planning-models.md) |
| Page content, UX writing, redundant copy, or text noise | [content design](references/content-design.md) |
| Feature explanations, comparisons, dense content, or default cards/accordions | [content to form](references/content-form.md): relevant relationships and disclosure decisions |
| Long pages, editorial sequences, decks, or variants that differ only at the top | [page composition](references/page-composition.md) |
| Meaningful novelty, alternatives, or a blocked visual concept | [creative search](references/creative-search.md); use only relevant operations |
| Visual creation or substantial restyling in any medium | [visual language](references/visual-language.md), applicable section of [media](references/media.md) |
| Card families, Material/glass/media/skeuomorphic cards, region hierarchy, or monotonous card variants | [card systems](references/card-systems.md): select role, composition and matching family |
| Surface fills, layered borders/shadows, or material refinement | [card and surface craft](references/card-surfaces.md): relevant layering or state section |
| Clipped select arrows, icon clearance, cropped focus/shadows, or native control mismatch | [component craft](references/component-craft.md): control geometry and clipping section |
| Looks generic, needs beauty, personality, or an open visual concept | [art direction](references/art-direction.md); follow its craft/style links selectively |
| Open style brief, contemporary expression, or monotonous candidates | [contemporary directions](references/contemporary-directions.md): selection table, then selected directions only; its case cards are optional evidence |
| A named art movement, cultural tradition, or style | [style atlas](references/style-atlas.md), then only the relevant family/card |
| Brand VI or a coherent identity across touchpoints | [brand identity](references/brand-identity.md) |
| Distinctive enterprise/B2B software beyond a default theme | [enterprise expression](references/enterprise-expression.md) |
| Learn from a named app, design system, designer, or reference | [product patterns](references/product-patterns.md) or [reference study](references/reference-study.md), as relevant |
| Interactive product or motion | [interaction and motion](references/interaction-motion.md) |
| Behavior, motivation, persuasion, conversion | [psychology](references/psychology.md) |
| Specific principle, heuristic review, deliberate exception | [principles](references/principles.md), [contracts](references/contracts.md) |
| Implementation or handoff | [implementation](references/implementation.md), [contracts](references/contracts.md) |
| Platform conventions or current inspiration | relevant section of [platforms](references/platforms.md) or [examples and trends](references/examples-trends.md); [sources](references/sources.md) for evidence |
| Completion or review | applicable [verification](references/verification.md) checks |
| Improve this skill from feedback | [learning](references/learning.md) |

For a small edit, preserve established decisions and inspect only affected relationships and states. Do not restart strategy or force multiple proposals for a settled direction. For iterative improvement, define the current target, deliverables, checks, and stopping condition; finish that increment without automatically starting the backlog. Use available specialist tools for native files/rendering when needed; this skill does not require another design skill to reason or specify a result.

## Decision loop

1. **Frame.** Identify audience, job, context, actual content, constraints, medium, and success. Separate facts, assumptions, unknowns, and taste. Ask only for consequential missing information; continue reversible exploration with explicit assumptions. Do not fabricate research, metrics, testimonials, or product capabilities.
2. **Structure.** Resolve scope, content relationships, navigation or narrative, and priorities before polish. Establish necessary facts, labels, actions, states, and meaningful expression before adding copy; never generate filler to fit a template. Use content design for new pages or text-noise problems. For substantial feature/editorial content, map the reader's question to a relationship and a suitable expression before choosing components; use content to form. Core claims, comparisons, and decision conditions must remain discoverable without opening a series of panels. Keep design rationale and implementation commentary in review material, outside product content unless users need it. Each page, slide, or spread has a primary intent; a multi-task workspace may have several clearly separated task regions. Follow the five planes when scope warrants it, without turning them into a waterfall.
3. **Explore.** If direction is open, prioritize the owner's contemporary exploration preferences in contemporary directions, subordinate to this user's brief and established brand. Produce 2–3 compositions with the same representative content and asset conditions; vary at least two of hierarchy, density rhythm, spatial organization, and image–type relationships. Check the set for repeated formulas: neither serif/beige/quiet whitespace nor dark/neon/cards is a universal default. Define a visual thesis, recommend one against the brief, and make it concrete. For a settled direction, refine it without forcing alternatives.
4. **Specify.** Establish a visual contract with actual values and roles for color, typography, space, layout, imagery, components, and applicable states/motion. Use task and content to choose whitespace and density. Maintain a shared semantic system across pages; translate it across media instead of scaling screenshots.
5. **Realize.** Deliver the requested artifact. Keep factual content reusable without automatically reusing its entire composition. Carry the visual language through dense body content, transitions, and the ending; use page composition for long sequences or multiple directions. Familiar controls may stay consistent; novelty must serve meaning rather than extra interaction. Cover key states, input methods, content extremes, responsive transformations, or physical production constraints as applicable. Connect intent → mechanism → concrete choice → observable check for consequential decisions.
6. **Inspect and revise.** Render and inspect the actual output when tools permit. Exercise key interactions or inspect every produced slide/page; fix visible defects and broken tasks. Audit rendered copy for irrelevant, redundant, unsupported, or process-only text; remove or rewrite it without losing necessary conditions, labels, accessible meaning, or recovery guidance, then recheck layout and tasks. Disclose missing checks. A checklist, source citation, or attractive screenshot alone cannot prove quality. For multi-direction visual delivery, compare body compositions as well as covers; reject repeated content-block formulas disguised by palettes. Keep technical checks and visual judgment as separate evidence.

## Judgment boundaries

Distinguish standards, platform conventions, empirical models, heuristics, and aesthetic choices. Apply psychology as testable contextual hypotheses. Explain rule-breaking through changed conditions, benefits, costs, safeguards, and a way to test or reverse it. Do not average serious task failures into a flattering beauty score.

Authority comes from sound reasoning and evidence, not brand worship or claims of mastery. Do not promise universal liking, optimality, conversion lifts, accessibility conformance, or exhaustive detail coverage without supporting evidence. Preserve informed choice; never invent scarcity or hide material conditions to improve clicks.

## Delivery

Lead with the artifact and consequential decisions, then state what was actually verified and any material gaps. Keep internal process proportional; deliver design rather than a theoretical essay unless the user requested one. Record transferable failures and improvements using the learning protocol; do not silently turn one client's preference into a global rule.
